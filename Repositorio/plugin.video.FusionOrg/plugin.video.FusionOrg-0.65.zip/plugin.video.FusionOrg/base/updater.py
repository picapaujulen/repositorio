# -*- coding: utf-8 -*-
from xml.dom import minidom
from xml.etree import ElementTree as ET
import base64
import control
import json
import os

import control
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
is_fusion_request = control.addon_details('plugin.video.FusionTv.Request', fields=[
                                          'enabled', 'installed', 'fanart', 'thumbnail'])
is_repo = control.addon_details('repository.Fusion.org', fields=[
                                'enabled', 'installed', 'fanart', 'thumbnail'])


def add_fusion_source():
    exist_source = False
    successful = False
    path_sources = xbmc.translatePath('special://userdata')
    path_sources = os.path.join(path_sources, 'sources.xml')

    #===========================================================================
    # try:
    #===========================================================================
    if os.path.exists(path_sources):
        xmldoc = minidom.parse(path_sources)
    else:
        xmldoc = minidom.Document()
        nodo_sources = xmldoc.createElement("sources")
        for type in ['programs', 'video', 'music', 'pictures', 'files', 'games']:
            nodo_type = xmldoc.createElement(type)
            element_default = xmldoc.createElement("default")
            element_default.setAttribute("pathversion", "1")
            nodo_type.appendChild(element_default)
            nodo_sources.appendChild(nodo_type)
            xmldoc.appendChild(nodo_sources)
    
    nodo_video = xmldoc.childNodes[0].getElementsByTagName("files")[0]
    nodos_paths = nodo_video.getElementsByTagName("path")
    list_path = []
    for path in nodos_paths:
        list_path += [path.firstChild.data]
    subfolder = 'https://repositorio.fusionorg.net/'
    if not subfolder in list_path:
        name = 'Repo FusionOrg'
        nodo_source = xmldoc.createElement("source")
        nodo_name = xmldoc.createElement("name")
        nodo_name.appendChild(xmldoc.createTextNode(name))
        nodo_source.appendChild(nodo_name)
        nodo_path = xmldoc.createElement("path")
        nodo_path.setAttribute("pathversion", "1")
        nodo_path.appendChild(xmldoc.createTextNode(subfolder))
        nodo_source.appendChild(nodo_path)
        nodo_allowsharing = xmldoc.createElement("allowsharing")
        nodo_allowsharing.appendChild(xmldoc.createTextNode('true'))
        nodo_source.appendChild(nodo_allowsharing)
        nodo_video.appendChild(nodo_source)
        successful = True
        exist_source = True
    else:
        exist_source = True
    
    content = '\n'.join([x for x in xmldoc.toprettyxml().encode("utf-8").splitlines() if x.strip()])
    write_file(path_sources, content)
        
    #===========================================================================
    # except:
    #     pass
    #===========================================================================

    if successful:
        control.infoDialog(
            'Se Agrego correctamente El Repo de FusionOrg a Sources.xml')
    elif not successful and exist_source:
        control.infoDialog('El Repo de FusionOrg ya esta en las fuentes')
    elif not successful and not exist_source:
        control.infoDialog(
            'Fallo al agregar la fuente de FusionOrg a Sources.xml')


def install_FOR():
    exist_repo = False
    enable_repo = False
    if ('enabled' or 'installed') in is_repo:
        exist_repo = True
        if is_repo['enabled']:
            xbmc.executebuiltin('InstallAddon(plugin.video.FusionTv.Request)')
            return
    add_fusion_source()
    xbmc.executebuiltin('InstallFromZip')


def force_update():
    add_fusion_source()
    xbmc.executebuiltin('UpdateAddonRepos')
    control.infoDialog('Repositorios actualizados!!!')

def write_file(file, buffer):
    handler = xbmcvfs.File(file,'w')
    result = handler.write(buffer)
    handler.close()
    return result
