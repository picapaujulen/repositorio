# -*- coding: utf-8 -*-
import json
import re
import urllib

import requests

from base import jsunpack
import xbmcgui


headers = {}
headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'
headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
headers['Accept-Encoding'] = 'deflate'


def read2(url, cookies_=''):
    data = 'Imposible conectar con el server'
    location = ''
    cookies = ''
    try:
        if cookies_ != '':
            response = requests.get(
                url, headers=headers, timeout=10, cookies=cookies_)
        else:
            response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.content
            location = response.headers.get('location')
            cookies = response.cookies
    except:
        pass
    return data, location, cookies


def urlgamovideo(url):
    if 'embed-' in url:
        id_gamo = re.findall('embed-(.*?).html', url, re.I)
        if len(id_gamo) > 0:
            id_gamo = id_gamo[0]
        else:
            id_gamo = ''
            url = url.replace('embed-', '')
    if not 'embed-' in url:
        id_gamo = re.findall('/(.*?).html', url, re.I)
        if len(id_gamo) > 0:
            id_gamo = id_gamo[0]
        else:
            id_gamo = re.findall('\/\/.*?\/(.*)', url, re.I)
            if len(id_gamo) > 0:
                id_gamo = id_gamo[0]
            else:
                id_gamo = ''
    if id_gamo != '':
        source, location, cookies = read2(
            'http://gamovideo.com/{}.html'.format(id_gamo))
    else:
        source, location, cookies = read2(url)
    domain_cookies = requests.cookies.RequestsCookieJar()
    domain_cookies = cookies._cookies.get(
        ".gamovideo.com", {}).get("/", {})
    domain_cookies.update(
        cookies._cookies.get("gamovideo.com", {}).get("/", {}))
    if id_gamo != '':
        source, location, cookies = read2(
            'http://gamovideo.com/{}.html'.format(id_gamo), cookies_=cookies)
    else:
        source, location, cookies = read2(url, cookies_=cookies)

    try:
        domain_cookies.update(cookies._cookies.get(
            ".gamovideo.com", {}).get("/", {}))
        domain_cookies.update(
            cookies._cookies.get("gamovideo.com", {}).get("/", {}))
    except:
        pass
    error = ''
    if 'Imposible conectar con el server' in source:
        error = 'Imposible conectar con el server'
    if 'File was deleted' in source or 'File Not Found' in source or 'File was locked by administrator' in source:
        error = 'El archivo no existe o ha sido borrado'
    if 'Video is processing now' in source:
        error = 'El video está procesándose en estos momentos. Inténtelo mas tarde.'
    if 'File is awaiting for moderation' in source:
        error = 'El video está esperando por moderación.'
    if error != '':
        dialog = xbmcgui.Dialog()
        dialog.notification('FusionOrg', 'Fallo: ' + error,
                            xbmcgui.NOTIFICATION_INFO, 5000, True)
        exit()

    source = re.sub('(\r){1,}', '', source)
    source = re.sub('(\n){1,}', '', source)
    source = re.sub('(\t){1,}', '', source)
    source = re.sub('(\s){1,}', ' ', source)
    header_test = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}
    gamo_player = re.findall(
        "src\s*=\s*\'(http.*?gamovideo.com\/player.*?\/jwplayer.js)\'", source, re.IGNORECASE)
    if len(gamo_player) > 0:
        nothing, location, cookies = read2(
            gamo_player[0], cookies_=domain_cookies)
        header_test['Referer'] = gamo_player[0]
        try:
            domain_cookies.update(cookies._cookies.get(
                ".gamovideo.com", {}).get("/", {}))
            domain_cookies.update(
                cookies._cookies.get("gamovideo.com", {}).get("/", {}))
        except:
            pass

    cookie_headers = []
    for c in domain_cookies.values():
        cookie_headers.append(c.name + '=' + c.value)
    if len(cookie_headers) > 0:
        header_test.update({'Cookie': ';'.join(cookie_headers)})
    jspacks = re.findall(
        "<script type=.text/javascript.>(eval.function.p,a,c,k,e,d..*?)</script>", source, re.IGNORECASE)
    if len(jspacks) > 0:
        for jspack in jspacks:
            source = source.replace(jspack, jsunpack.unpack(jspack))

    finalurlgamo = re.findall(
        'file:\s*\"(http.*?mp4)\"', source, re.IGNORECASE)[0]
    header_test = '|' + urllib.urlencode(header_test)
    return finalurlgamo + header_test
