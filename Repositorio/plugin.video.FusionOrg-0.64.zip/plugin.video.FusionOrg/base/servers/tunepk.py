import base64
import hashlib
import json
import os
import re
import time
import urllib
import urlparse

from base import jsunpack
from resources.lib.conector import conect
import requests
import xbmc
import xbmcaddon
import xbmcgui


addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addon_dir = xbmc.translatePath(xbmc.translatePath(
    addon.getAddonInfo('Path')).decode('utf-8'))

data_path = xbmc.translatePath(addon.getAddonInfo('Profile'))
if not os.path.exists(data_path):
    os.makedirs(data_path)

icon = os.path.join(addon_dir, 'icon.png')


default_headers = dict()
default_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36'
default_headers['Referer'] = 'https://tune.pk/'


def test_tunepk(url):
    response = conect.get_url(url, h=default_headers)
    if response != 'Imposible conectar con el server':
        if response.status_code == 200:
            return True, response.content
        if response.status_code == 404:
            return False, response.content
    return False, 'Imposible conectar con el server'

# def calidades_vshare(url):


def tunepk(url):
    calidad = ''
    if 'calidad' in url:
        calidad = urlparse.parse_qs(url)['calidad'][0]
        url = url.split('&')[0]

    valid, data = test_tunepk(url)
    calidades = []
    finallinks = []
    if valid:
        sources = re.findall(
            "\"sources\":(\[.*?\])", data, re.IGNORECASE)
        if len(sources) > 0:
            sources = json.loads(sources[0])
            if calidad == '':
                for source in sources:
                    if not '-' in str(source['bitrate']):
                        calidades += [str(source['bitrate'])]
                return True, calidades
            else:
                finallink = url
                for source in sources:
                    if calidad == str(source['bitrate']):
                        finallink = source['file']
            if finallink == '':
                finallink = re.findall(
                    '\"file\":\"(.*?)\"', data, re.I)[0]

            if finallink != '':
                url_attr = urlparse.urlparse(finallink)
                url_qs = urlparse.parse_qs(url_attr[4])
                ttl = int(eval(url_qs.get('ttl', ['time.time()+3600'])[0]))
                ttl += 1
                token = hashlib.md5(
                    str(ttl) + url_attr[2] + ' c@ntr@lw3biutun3cb').digest()
                token = base64.urlsafe_b64encode(
                    token).replace('=', '').replace('\n', '')
                query = '?h=' + token + '&ttl=' + str(ttl)
                finallink = url_attr[0] + '://' + \
                    url_attr[1] + url_attr[2] + query
                return True, finallink + '|' + urllib.urlencode(default_headers)
            return True, url
    return False, 'Tunepk fallo!!!'
