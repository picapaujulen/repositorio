# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# Modificación eliminar indigo del sistema. Proveedor: CTA
# ----------------------------------------------------------------------------
#######################################################################


import shutil

import xbmc



addon_path = xbmc.translatePath(('special://home/addons/plugin.program.indigo')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.blackghost')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.Ghostbusters')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/repository.Ghostbusters')).decode('utf-8')


xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.palantir)')



shutil.rmtree(addon_path, ignore_errors=True)
