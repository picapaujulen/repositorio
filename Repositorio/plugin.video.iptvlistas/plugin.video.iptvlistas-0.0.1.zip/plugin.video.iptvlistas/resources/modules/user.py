import base64 as b

id   = 'plugin.video.iptvlistas'

name = '[COLOR lime]iptv listas[/COLOR]'

host = b.b64decode('aHR0cDovL2FwbGkxLnNlbGZpcC5jb20=')

port = b.b64decode('ODAwMA==')